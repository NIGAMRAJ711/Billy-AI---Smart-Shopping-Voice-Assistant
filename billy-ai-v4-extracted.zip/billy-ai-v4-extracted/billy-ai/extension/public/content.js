// content.js v4 — Billy AI
// Fixes: voice reliability, smart chat, compare, delivery, price history, URLs

const BACKEND_WS = "ws://localhost:8000/ws";
let ws = null, wsReady = false;
let billyVoice = null;
let lastProducts = [];
let isListening = false;
let wakeLoop = null, wakeActive = false;

// ── Voice setup ──────────────────────────────────────────────────
const loadVoice = () => {
  const vs = window.speechSynthesis.getVoices();
  const want = ["Google UK English Female",
    "Microsoft Sonia Online (Natural) - English (United Kingdom)",
    "Microsoft Aria Online (Natural) - English (United States)",
    "Samantha", "Karen", "Moira"];
  for (const n of want) { const v = vs.find(x => x.name === n); if (v) { billyVoice = v; return; } }
  billyVoice = vs.find(v => /female|woman/i.test(v.name)) || vs.find(v => v.lang.startsWith("en")) || null;
};
window.speechSynthesis.onvoiceschanged = loadVoice;
loadVoice();

function speak(text) {
  window.speechSynthesis.cancel();
  // Strip emoji and special chars for cleaner speech
  const clean = text.replace(/[\u{1F300}-\u{1FFFF}]/gu, "").replace(/[★☆🏆💰⭐🚚✅❌🔍]/g, "").trim();
  const u = new SpeechSynthesisUtterance(clean);
  if (billyVoice) u.voice = billyVoice;
  u.rate = 0.9; u.pitch = 1.2; u.volume = 1.0; u.lang = "en-IN";
  window.speechSynthesis.speak(u);
}

// ── WebSocket ────────────────────────────────────────────────────
function connectWS() {
  try {
    ws = new WebSocket(BACKEND_WS);
    ws.onopen  = () => { wsReady = true; setStatus("Connected to Billy backend"); };
    ws.onmessage = e => handleBackend(JSON.parse(e.data));
    ws.onclose = () => { wsReady = false; setTimeout(connectWS, 2000); };
    ws.onerror = () => { wsReady = false; };
  } catch(e) { setTimeout(connectWS, 3000); }
}

function sendWS(type, payload) {
  if (!wsReady) { setStatus("Backend not connected — start python main.py"); return false; }
  ws.send(JSON.stringify({ type, payload }));
  return true;
}

// ── Handle backend messages ───────────────────────────────────────
function handleBackend(msg) {
  switch(msg.type) {
    case "chat_reply":
      const text = msg.data?.text || "";
      addMsg(text, "billy");
      speak(text);
      setStatus("");
      break;
    case "status":
      setStatus(msg.message || "");
      break;
    case "product_found":
      lastProducts = lastProducts.filter(p => p.asin !== msg.data.asin);
      lastProducts.push(msg.data);
      renderLiveTable(lastProducts);
      showSection("billy-results");
      break;
    case "scored_products":
      lastProducts = msg.data;
      renderScoredTable(msg.data);
      break;
    case "recommendation":
      renderWinnerCards(msg.data);
      if (msg.data.billy_says) { addMsg(msg.data.billy_says, "billy"); speak(msg.data.billy_says); }
      setStatus("");
      break;
    case "analysis":
      renderAnalysis(msg.data);
      if (msg.data.billy_says) { addMsg(msg.data.billy_says, "billy"); speak(msg.data.billy_says); }
      setStatus("");
      break;
    case "error":
      addMsg(msg.message, "billy"); speak(msg.message); setStatus("");
      break;
  }
}

// ── Smart input handler ───────────────────────────────────────────
function handleInput(text) {
  if (!text.trim()) return;
  setText("");
  addMsg(text, "user");
  setStatus("Billy is thinking...");

  const t = text.toLowerCase().trim();

  // Greetings — pure chat
  if (/^(hey|hi|hello|yo|howdy|sup)\b/.test(t) && t.split(" ").length <= 3) {
    sendWS("CHAT", { text, pageContext: getPageContext() });
    return;
  }

  // Compare command
  if (/\b(compare|vs|versus|which is better|rank these|rank them)\b/.test(t)) {
    sendWS("SEARCH_AND_COMPARE", { text, query: text, pageContext: getPageContext() });
    return;
  }

  // Analyse current product
  if (/\b(analyse|analyze|review|tell me about|should i buy|worth|delivery|specs|features|fake review|seller)\b/.test(t)) {
    const pageData = scrapeCurrentPage();
    if (pageData.name) {
      sendWS("ANALYZE_PAGE", { pageData });
    } else {
      sendWS("CHAT", { text, pageContext: getPageContext() });
    }
    return;
  }

  // Price history request
  if (/\b(price history|price trend|was cheaper|price drop|track price)\b/.test(t)) {
    const pageData = scrapeCurrentPage();
    if (pageData.asin) {
      showPriceHistory(pageData.asin, pageData.name);
    } else {
      addMsg("Go to a specific product page first, then ask me about price history!", "billy");
      speak("Go to a specific product page first, then ask me about price history!");
    }
    setStatus("");
    return;
  }

  // Product search
  if (/\b(find|search|look for|show me|i need|i want|buy|best|cheapest|top|recommend)\b/.test(t)) {
    lastProducts = [];
    hideSection("billy-results");
    sendWS("SEARCH_AND_COMPARE", { text, query: text, pageContext: getPageContext() });
    return;
  }

  // Default — chat
  sendWS("CHAT", { text, pageContext: getPageContext() });
}

// ── Scrape current page ───────────────────────────────────────────
function scrapeCurrentPage() {
  const qs = s => document.querySelector(s)?.innerText?.trim();
  const asinMatch = window.location.href.match(/\/dp\/([A-Z0-9]{10})/);
  return {
    name:          qs("#productTitle"),
    price:         qs(".a-price-whole"),
    rating:        qs("#acrPopover [title]") || qs(".a-icon-alt"),
    review_count:  qs("#acrCustomerReviewText"),
    delivery:      qs("#deliveryBlockMessage, #mir-layout-DELIVERY_BLOCK, .a-color-success"),
    delivery_date: qs("#deliveryMessageMirId, .a-color-success"),
    seller:        qs("#merchant-info, #sellerProfileTriggerId"),
    availability:  qs("#availability span"),
    bank_offer:    qs("#sopp_feature_div"),
    asin:          asinMatch ? asinMatch[1] : null,
    url:           window.location.href,
  };
}

function getPageContext() {
  const p = scrapeCurrentPage();
  if (!p.name) return "";
  return `User is viewing: ${p.name} | Price: Rs.${p.price||"?"} | Rating: ${p.rating||"?"} | Delivery: ${p.delivery||"?"} | Reviews: ${p.review_count||"?"}`;
}

// ── Price History ─────────────────────────────────────────────────
function showPriceHistory(asin, name) {
  const url = `https://pricehistory.app/product/${asin}`;
  window.open(url, "_blank");
  const msg = `Opening price history for ${(name||"this product").slice(0,40)}. pricehistory.app tracks prices on Amazon India and shows if it's a good time to buy!`;
  addMsg(msg, "billy");
  speak("Opening price history. I'll check if this is a good time to buy!");
}

// ── Render: live product table ────────────────────────────────────
function renderLiveTable(products) {
  const el = document.getElementById("billy-live-table");
  const title = document.getElementById("billy-results-title");
  if (title) title.textContent = `Found ${products.length} products...`;
  if (el) el.innerHTML = buildTable(products, false);
}

function renderScoredTable(products) {
  const el = document.getElementById("billy-live-table");
  const title = document.getElementById("billy-results-title");
  if (title) title.textContent = `Scored ${products.length} products`;
  if (el) el.innerHTML = buildTable(products, true);
}

function buildTable(products, scored) {
  let html = `<div class="b-tbl-wrap"><table class="b-tbl">
    <thead><tr><th>#</th><th>Product</th><th>Price</th><th>Rating</th><th>Reviews</th><th>Delivery</th>${scored?"<th>Score</th>":""}
    <th>Actions</th></tr></thead><tbody>`;
  products.slice(0,8).forEach((p,i) => {
    const tag = p.tag ? `<span class="b-tag b-tag-${(p.tag||"").replace(/_/g,"")}">${(p.tag||"").replace(/_/g," ")}</span>` : "";
    const score = scored && p.overall_score ? `<span class="b-score">${p.overall_score}</span>` : "";
    // Clean Amazon URL — strip sponsored redirects
    const cleanUrl = cleanAmazonUrl(p.url, p.asin);
    const historyUrl = p.asin ? `https://pricehistory.app/product/${p.asin}` : null;
    html += `<tr class="b-tbl-row">
      <td>${i+1}</td>
      <td class="b-tbl-name" title="${p.name||""}">${(p.name||"?").slice(0,50)}... ${tag}</td>
      <td class="b-tbl-price">₹${p.price||"?"}<br>${p.discount?`<small class="b-disc">-${p.discount}%</small>`:""}</td>
      <td>${p.rating||"?"}⭐</td>
      <td><small>${formatReviews(p.reviews)}</small></td>
      <td><small>${(p.delivery||"Check page").slice(0,35)}</small>${p.prime?"<br><span class='b-prime'>Prime</span>":""}</td>
      ${scored?`<td>${score}</td>`:""}
      <td class="b-action-cell">
        ${cleanUrl ? `<button class="b-btn-open" onclick="window.open('${cleanUrl}','_blank')">Open ↗</button>` : ""}
        ${historyUrl ? `<button class="b-btn-history" onclick="window.open('${historyUrl}','_blank')">📈 History</button>` : ""}
      </td>
    </tr>`;
  });
  html += "</tbody></table></div>";
  return html;
}

function cleanAmazonUrl(url, asin) {
  // If we have ASIN, build a direct clean URL — no sponsored redirects
  if (asin) return `https://www.amazon.in/dp/${asin}`;
  if (!url) return null;
  // Remove /sspa/click sponsored wrapper
  if (url.includes("/sspa/click")) {
    const match = url.match(/url=([^&]+)/);
    if (match) return "https://www.amazon.in" + decodeURIComponent(match[1]).split("?")[0];
  }
  return url.startsWith("http") ? url : "https://www.amazon.in" + url;
}

function formatReviews(reviews) {
  if (!reviews) return "No data";
  const n = parseInt(reviews.replace(/,/g,""));
  if (isNaN(n)) return reviews;
  if (n >= 1000) return (n/1000).toFixed(1) + "k ratings";
  return n + " ratings";
}

// ── Winner cards ──────────────────────────────────────────────────
function renderWinnerCards(data) {
  const row = document.getElementById("billy-winner-row");
  row?.classList.remove("b-hidden");

  const makeCard = (id, product, label, emoji) => {
    if (!product) return;
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove("b-hidden");
    const cleanUrl = cleanAmazonUrl(product.url, product.asin);
    const histUrl  = product.asin ? `https://pricehistory.app/product/${product.asin}` : null;
    el.innerHTML = `
      <div class="b-card-label">${emoji} ${label}</div>
      <div class="b-card-name">${(product.name||"").slice(0,55)}...</div>
      <div class="b-card-price">₹${product.price||"?"}</div>
      <div class="b-card-chips">
        <span>⭐${product.rating||"?"}</span>
        <span>${formatReviews(product.reviews)}</span>
        ${product.prime?"<span class='b-prime'>Prime</span>":""}
      </div>
      <div class="b-card-score">Score: ${product.overall_score||"?"}/10</div>
      <div class="b-card-reason">${product.reason||""}</div>
      <div class="b-card-actions">
        ${cleanUrl ? `<button class="b-card-btn" onclick="window.open('${cleanUrl}','_blank')">Open on Amazon ↗</button>` : ""}
        ${histUrl  ? `<button class="b-card-btn b-card-btn-hist" onclick="window.open('${histUrl}','_blank')">📈 Price History</button>` : ""}
      </div>
    `;
  };

  makeCard("billy-card-best",    data.best_overall, "Best Overall",  "🏆");
  makeCard("billy-card-budget",  data.best_budget,  "Best Budget",   "💰");
  makeCard("billy-card-premium", data.best_premium, "Best Premium",  "⭐");
}

// ── Analysis card ─────────────────────────────────────────────────
function renderAnalysis(data) {
  const msgs = document.getElementById("billy-msgs");
  if (!msgs) return;
  const el = document.createElement("div");
  el.className = "b-analysis-card";
  el.innerHTML = `
    <div class="b-analysis-verdict b-verdict-${data.verdict||"consider"}">
      ${data.verdict==="buy"?"✅ Buy it":data.verdict==="avoid"?"❌ Skip":"🤔 Consider"}
      ${data.overall_score ? ` · ${data.overall_score}/10` : ""}
    </div>
    <div class="b-analysis-row"><b>Value:</b> ${data.value_for_money||"?"}</div>
    <div class="b-analysis-row"><b>Review authenticity:</b> ${data.fake_review_risk||"?"} risk — ${data.fake_review_reason||""}</div>
    <div class="b-analysis-row"><b>Delivery:</b> ${data.delivery_summary||"?"}</div>
    <div class="b-analysis-pros">${(data.pros||[]).map(p=>`✅ ${p}`).join("<br>")}</div>
    <div class="b-analysis-cons">${(data.cons||[]).map(c=>`❌ ${c}`).join("<br>")}</div>
    <div class="b-analysis-for"><b>Best for:</b> ${data.best_for||"?"}</div>
  `;
  msgs.appendChild(el);
  msgs.scrollTop = 99999;
}

// ── VOICE ENGINE — reliable, never drops ─────────────────────────
function startWakeWord() {
  if (!("webkitSpeechRecognition" in window)) return;
  if (wakeActive) return;

  const SR = window.webkitSpeechRecognition;
  const rec = new SR();
  rec.continuous = true;
  rec.interimResults = true;
  rec.lang = "en-IN";
  rec.maxAlternatives = 1;

  let lastWake = 0;
  rec.onresult = ({ results, resultIndex }) => {
    for (let i = resultIndex; i < results.length; i++) {
      const t = results[i][0].transcript.toLowerCase().trim();
      if (/\b(hey|hi|ok)?\s*billy\b/.test(t) && Date.now() - lastWake > 3000) {
        lastWake = Date.now();
        openPanel();
        const greet = "Hey! I'm Billy, your shopping assistant. What are you looking for today?";
        addMsg(greet, "billy");
        speak(greet);
        setTimeout(() => startSessionListen(), 1400);
      }
    }
  };
  rec.onerror = e => { if (e.error !== "aborted") setTimeout(startWakeWord, 1000); };
  rec.onend   = () => { if (wakeActive) setTimeout(() => { try { rec.start(); } catch(e){} }, 300); };
  wakeActive = true;
  wakeLoop = rec;
  try { rec.start(); } catch(e) {}
}

function stopWakeWord() { wakeActive = false; try { wakeLoop?.stop(); } catch(e){} }

function startSessionListen() {
  if (!("webkitSpeechRecognition" in window)) return;
  if (isListening) return;
  stopWakeWord();
  isListening = true;

  const SR = window.webkitSpeechRecognition;
  const rec = new SR();
  rec.continuous = false;
  rec.interimResults = true;
  rec.maxAlternatives = 3;
  rec.lang = "en-IN";

  const micBtn = document.getElementById("billy-mic-btn");
  const micDot = document.getElementById("billy-mic-dot");
  let ghostEl = null, done = false;

  rec.onstart = () => {
    setStatus("🎤 Listening — speak now...");
    if (micBtn) micBtn.textContent = "🔴";
    if (micDot) micDot.textContent = "🔴";
  };

  rec.onresult = ({ results }) => {
    const best = results[0];
    const text = best[0].transcript;
    if (!best.isFinal) {
      if (!ghostEl) {
        ghostEl = document.createElement("div");
        ghostEl.className = "b-msg b-msg-interim";
        document.getElementById("billy-msgs")?.appendChild(ghostEl);
      }
      ghostEl.textContent = text + "...";
      document.getElementById("billy-msgs").scrollTop = 99999;
    } else if (!done) {
      done = true;
      ghostEl?.remove(); ghostEl = null;
      handleInput(text);
    }
  };

  rec.onerror = e => {
    ghostEl?.remove();
    if (e.error === "no-speech") setStatus("Didn't catch that — tap mic or type");
    else setStatus("Mic error: " + e.error);
  };

  rec.onend = () => {
    isListening = false;
    if (micBtn) micBtn.textContent = "🎤";
    if (micDot) micDot.textContent = "";
    if (!done) setStatus("");
    // Restart wake word after session
    setTimeout(startWakeWord, 800);
  };

  try { rec.start(); } catch(e) { isListening = false; setStatus("Mic unavailable"); startWakeWord(); }
}

// ── UI ────────────────────────────────────────────────────────────
function createUI() {
  if (document.getElementById("billy-root")) return;
  const root = document.createElement("div");
  root.id = "billy-root";
  root.innerHTML = `
    <div id="billy-bubble" title="Say Hey Billy or click">
      <div class="b-ring b-ring-outer"></div>
      <div class="b-ring b-ring-inner"></div>
      <svg id="billy-face" width="38" height="38" viewBox="0 0 48 48" fill="none">
        <circle cx="24" cy="22" r="14" fill="white" opacity="0.95"/>
        <ellipse cx="19.5" cy="20" rx="2" ry="2.5" fill="#6C63FF"/>
        <ellipse cx="28.5" cy="20" rx="2" ry="2.5" fill="#6C63FF"/>
        <circle cx="20.3" cy="19" r="0.8" fill="white"/>
        <circle cx="29.3" cy="19" r="0.8" fill="white"/>
        <path d="M18 25 Q24 30 30 25" stroke="#6C63FF" stroke-width="2" stroke-linecap="round" fill="none"/>
        <ellipse cx="16" cy="24" rx="3" ry="1.8" fill="#FFB3C6" opacity="0.6"/>
        <ellipse cx="32" cy="24" rx="3" ry="1.8" fill="#FFB3C6" opacity="0.6"/>
      </svg>
    </div>

    <div id="billy-panel" class="b-hidden">
      <div id="billy-header">
        <div id="billy-avatar-wrap">
          <svg width="30" height="30" viewBox="0 0 48 48" fill="none">
            <circle cx="24" cy="22" r="13" fill="white" opacity="0.9"/>
            <ellipse cx="19.5" cy="20" rx="2" ry="2.4" fill="#6C63FF"/>
            <ellipse cx="28.5" cy="20" rx="2" ry="2.4" fill="#6C63FF"/>
            <path d="M18 25 Q24 30 30 25" stroke="#6C63FF" stroke-width="1.8" stroke-linecap="round" fill="none"/>
            <ellipse cx="16" cy="24" rx="2.5" ry="1.5" fill="#FFB3C6" opacity="0.6"/>
            <ellipse cx="32" cy="24" rx="2.5" ry="1.5" fill="#FFB3C6" opacity="0.6"/>
          </svg>
        </div>
        <div id="billy-head-text">
          <span id="billy-name">Billy ✨</span>
          <span id="billy-sub">your shopping bestie</span>
        </div>
        <span id="billy-mic-dot"></span>
        <button id="billy-close">✕</button>
      </div>

      <div id="billy-statusbar"></div>

      <div id="billy-results" class="b-hidden">
        <div id="billy-results-header">
          <span id="billy-results-title">Searching...</span>
          <button class="b-compare-trigger" onclick="handleInput('compare these products')">⚖️ Compare</button>
        </div>
        <div id="billy-live-table"></div>
        <div id="billy-winner-row" class="b-hidden">
          <div id="billy-card-best"    class="b-winner-card b-hidden"></div>
          <div id="billy-card-budget"  class="b-winner-card b-card-budget b-hidden"></div>
          <div id="billy-card-premium" class="b-winner-card b-card-premium b-hidden"></div>
        </div>
      </div>

      <div id="billy-chat"><div id="billy-msgs">
        <div class="b-msg b-msg-billy">Hey! I'm Billy 👋 Say what you're looking for, or ask me anything about a product on screen!</div>
      </div></div>

      <div id="billy-input-row">
        <button id="billy-mic-btn" title="Tap to speak">🎤</button>
        <input id="billy-text-input" type="text" placeholder="Ask Billy anything..."/>
        <button id="billy-send-btn">➤</button>
      </div>
      <div id="billy-status"></div>
    </div>
  `;
  document.body.appendChild(root);
  bindEvents();
  connectWS();
  startWakeWord();
}

function bindEvents() {
  document.getElementById("billy-bubble")?.addEventListener("click", () => {
    const panel = document.getElementById("billy-panel");
    panel?.classList.toggle("b-hidden");
    if (!panel?.classList.contains("b-hidden")) {
      const p = scrapeCurrentPage();
      if (p.name) speak(`Hi! I can see you're looking at ${p.name.slice(0,35)}. Ask me anything about it!`);
    }
  });
  document.getElementById("billy-close")?.addEventListener("click", () =>
    document.getElementById("billy-panel")?.classList.add("b-hidden"));
  document.getElementById("billy-mic-btn")?.addEventListener("click", () => {
    openPanel();
    startSessionListen();
  });
  document.getElementById("billy-send-btn")?.addEventListener("click", () => {
    const v = document.getElementById("billy-text-input")?.value?.trim();
    if (v) handleInput(v);
  });
  document.getElementById("billy-text-input")?.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      const v = e.target.value.trim();
      if (v) handleInput(v);
    }
  });
}

// ── Helpers ───────────────────────────────────────────────────────
function addMsg(text, role = "billy") {
  const msgs = document.getElementById("billy-msgs");
  if (!msgs) return;
  const el = document.createElement("div");
  el.className = `b-msg b-msg-${role}`;
  el.textContent = text;
  msgs.appendChild(el);
  msgs.scrollTop = 99999;
}
function setStatus(t) {
  const s = document.getElementById("billy-status");
  const b = document.getElementById("billy-statusbar");
  if (s) s.textContent = t;
  if (b) b.textContent = t;
}
function setText(t) { const i = document.getElementById("billy-text-input"); if (i) i.value = t; }
function openPanel() { document.getElementById("billy-panel")?.classList.remove("b-hidden"); }
function showSection(id) { document.getElementById(id)?.classList.remove("b-hidden"); }
function hideSection(id) { document.getElementById(id)?.classList.add("b-hidden"); }

createUI();
