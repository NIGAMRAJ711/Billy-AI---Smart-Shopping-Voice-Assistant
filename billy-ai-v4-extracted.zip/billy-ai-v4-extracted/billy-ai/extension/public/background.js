// background.js — service worker
// Minimal — all logic is in content.js + Python backend
chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] })
    .catch(() => {});
});
