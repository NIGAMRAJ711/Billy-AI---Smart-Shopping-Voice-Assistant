@echo off
echo Setting up Billy AI...

echo Installing Python dependencies...
cd backend
python -m venv venv
call venv\Scripts\activate
pip install -r requirements.txt
playwright install chromium
copy .env.example .env
echo Backend ready

echo Installing extension dependencies...
cd ..\extension
npm install
npm run build
echo Extension built

echo.
echo Setup complete!
echo Next: Add your API key to backend\.env
echo Then run: cd backend ^&^& python main.py
pause
