// shared/constants.js
// These constants are shared between the extension and backend docs

const BILLY_CONFIG = {
  BACKEND_URL:   "http://localhost:8000",
  BACKEND_WS:    "ws://localhost:8000/ws",
  WAKE_WORD:     "billy",
  MAX_PRODUCTS:  10,
  CACHE_TTL:     3600,   // seconds

  // WebSocket message types (extension → backend)
  MSG_SEARCH:   "SEARCH_AND_COMPARE",
  MSG_ANALYZE:  "ANALYZE_PAGE",
  MSG_PING:     "PING",

  // WebSocket message types (backend → extension)
  MSG_ACK:          "ack",
  MSG_STATUS:       "status",
  MSG_PRODUCT:      "product_found",
  MSG_SCORED:       "scored_products",
  MSG_RECOMMEND:    "recommendation",
  MSG_ANALYSIS:     "analysis",
  MSG_ERROR:        "error",
};

module.exports = BILLY_CONFIG;
