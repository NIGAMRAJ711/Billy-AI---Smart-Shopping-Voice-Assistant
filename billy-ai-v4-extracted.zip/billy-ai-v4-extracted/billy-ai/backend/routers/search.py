from fastapi import APIRouter
router = APIRouter()

@router.get("/")
async def search(q: str = ""):
    return {"query": q, "note": "Use WebSocket /ws for real-time streaming search"}
