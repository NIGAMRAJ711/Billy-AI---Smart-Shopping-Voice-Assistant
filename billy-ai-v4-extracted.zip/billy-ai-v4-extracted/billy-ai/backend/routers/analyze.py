from fastapi import APIRouter
router = APIRouter()

@router.get("/")
async def analyze():
    return {"note": "Use WebSocket /ws with type: ANALYZE_PAGE"}
