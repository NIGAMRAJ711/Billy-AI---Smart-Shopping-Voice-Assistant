from fastapi import APIRouter
router = APIRouter()

@router.get("/")
async def compare():
    return {"note": "Use WebSocket /ws with type: SEARCH_AND_COMPARE"}
