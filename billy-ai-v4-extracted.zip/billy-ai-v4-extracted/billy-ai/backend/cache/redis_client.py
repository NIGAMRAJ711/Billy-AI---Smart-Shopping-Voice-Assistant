"""
cache/redis_client.py
Redis caching layer. Caches search results so repeated queries
return instantly without hitting Amazon again.
Falls back gracefully if Redis isn't running.
"""

import json
import os
import hashlib

redis_client = None
CACHE_TTL = int(os.getenv("CACHE_TTL_SECONDS", 3600))  # 1 hour default


async def init_cache():
    global redis_client
    try:
        import redis.asyncio as aioredis
        redis_client = await aioredis.from_url(
            os.getenv("REDIS_URL", "redis://localhost:6379"),
            decode_responses=True
        )
        await redis_client.ping()
        print("✅ Redis cache connected")
    except Exception as e:
        print(f"⚠️  Redis not available ({e}) — running without cache")
        redis_client = None


async def close_cache():
    if redis_client:
        await redis_client.aclose()


def _key(query: str) -> str:
    """Generate a stable cache key from a query string."""
    normalized = query.lower().strip()
    h = hashlib.md5(normalized.encode()).hexdigest()[:8]
    return f"billy:search:{h}"


async def get_cached(query: str) -> list | None:
    """Return cached results for query, or None if not cached."""
    if not redis_client:
        return None
    try:
        raw = await redis_client.get(_key(query))
        if raw:
            print(f"⚡ Cache HIT: {query}")
            return json.loads(raw)
    except Exception:
        pass
    return None


async def set_cache(query: str, products: list):
    """Cache products for a query."""
    if not redis_client:
        return
    try:
        await redis_client.setex(_key(query), CACHE_TTL, json.dumps(products))
        print(f"💾 Cached: {query} ({len(products)} products)")
    except Exception as e:
        print(f"⚠️  Cache write failed: {e}")


async def invalidate(query: str):
    """Force refresh a cached query."""
    if redis_client:
        await redis_client.delete(_key(query))
