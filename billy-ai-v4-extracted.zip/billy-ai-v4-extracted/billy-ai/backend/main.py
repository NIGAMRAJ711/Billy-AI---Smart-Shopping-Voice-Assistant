"""
Billy AI — FastAPI Backend v2
Fixes: chat mode, compare vs search, delivery dates
"""

import asyncio
import json
import os
import re
from contextlib import asynccontextmanager

import uvicorn
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from groq import Groq

load_dotenv()

from routers.search   import router as search_router
from routers.analyze  import router as analyze_router
from routers.compare  import router as compare_router
from cache.redis_client import init_cache, close_cache

groq_client = Groq(api_key=os.getenv("GROQ_API_KEY"))
GROQ_MODEL  = os.getenv("GROQ_MODEL", "llama3-70b-8192")

BILLY_SYSTEM = """You are Billy, a friendly smart AI shopping assistant built into the browser.
Personality: warm, witty, helpful — like a knowledgeable best friend.
Rules:
- Keep replies SHORT (2-4 sentences max) — you speak these aloud
- When user says hi/hello/hey — greet them warmly and ask what they are looking for
- When asked about products on the current page — give direct honest advice
- NEVER say you cannot help — always give a useful response
- Use light emoji when it fits the tone
- For Indian market: mention Rs. prices, mention value for money
- If asked something off-topic — answer briefly then bring back to shopping"""

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Billy AI starting up...")
    await init_cache()
    print("Billy AI ready — say Hey Billy!")
    yield
    await close_cache()

app = FastAPI(title="Billy AI", version="2.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.include_router(search_router,  prefix="/search")
app.include_router(analyze_router, prefix="/analyze")
app.include_router(compare_router, prefix="/compare")


class ConnectionManager:
    def __init__(self): self.connections: list[WebSocket] = []
    async def connect(self, ws): await ws.accept(); self.connections.append(ws)
    def disconnect(self, ws):
        if ws in self.connections: self.connections.remove(ws)
    async def send(self, ws, data):
        try: await ws.send_text(json.dumps(data))
        except: pass

manager = ConnectionManager()


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    print("Extension connected")
    try:
        while True:
            raw = await websocket.receive_text()
            msg = json.loads(raw)
            await handle_message(websocket, msg)
    except WebSocketDisconnect:
        manager.disconnect(websocket)


async def handle_message(ws, msg):
    msg_type = msg.get("type")
    payload  = msg.get("payload", {})
    if   msg_type == "SEARCH_AND_COMPARE": await handle_search_compare(ws, payload)
    elif msg_type == "ANALYZE_PAGE":       await handle_analyze(ws, payload)
    elif msg_type == "CHAT":               await handle_chat(ws, payload)
    elif msg_type == "PING":               await manager.send(ws, {"type": "pong"})


async def handle_chat(ws, payload):
    """Pure conversational reply — no search, no scrape."""
    text     = payload.get("text", "")
    page_ctx = payload.get("pageContext", "")
    
    user_msg = text
    if page_ctx:
        user_msg = f"Context: {page_ctx}\n\nUser: {text}"
    
    reply = await groq_chat(user_msg)
    await manager.send(ws, {"type": "chat_reply", "data": {"text": reply}, "done": True})


async def handle_search_compare(ws, payload):
    from ai.intent      import extract_intent
    from scrapers.amazon import scrape_search_results
    from ai.scorer      import score_products
    from ai.recommender import build_recommendation
    from cache.redis_client import get_cached, set_cache

    query    = payload.get("query", "")
    raw_text = payload.get("text", query)

    intent = await extract_intent(raw_text)
    
    # If intent is chat — reply conversationally
    if intent["intent"] == "chat":
        page_ctx = payload.get("pageContext", "")
        reply = await groq_chat(raw_text, page_ctx)
        await manager.send(ws, {"type": "chat_reply", "data": {"text": reply}, "done": True})
        return

    # If compare intent — compare already-found products
    if intent["intent"] == "compare":
        await manager.send(ws, {"type": "status", "message": "Comparing products already found..."})
        cached = await get_cached("__last_results__")
        if cached and len(cached) >= 2:
            scored = await score_products(cached, intent)
            await manager.send(ws, {"type": "scored_products", "data": scored})
            rec = await build_recommendation(scored, intent)
            await manager.send(ws, {"type": "recommendation", "data": rec, "done": True})
        else:
            reply = "I need to find some products first! Tell me what you want, like \'find best gaming mouse\' and then I can compare them for you."
            await manager.send(ws, {"type": "chat_reply", "data": {"text": reply}, "done": True})
        return

    # If analyze — analyze current page
    if intent["intent"] == "analyze_page":
        page_data = payload.get("pageData", {})
        await handle_analyze(ws, {"pageData": page_data})
        return

    # Search intent — scrape Amazon
    search_query = intent["query"]
    if not search_query or len(search_query) < 2:
        reply = "What product are you looking for? Just tell me something like \'find best headphones under 2000\'!"
        await manager.send(ws, {"type": "chat_reply", "data": {"text": reply}, "done": True})
        return

    await manager.send(ws, {"type": "status", "message": f"Searching Amazon for {search_query}..."})

    # Check cache first
    cached = await get_cached(search_query)
    if cached:
        await manager.send(ws, {"type": "status", "message": "Found cached results — scoring..."})
        for i, p in enumerate(cached):
            await manager.send(ws, {"type": "product_found", "data": p, "count": i+1})
        products = cached
    else:
        products = []
        async for product in scrape_search_results(search_query):
            products.append(product)
            await manager.send(ws, {"type": "product_found", "data": product, "count": len(products)})
        if products:
            await set_cache(search_query, products)
            await set_cache("__last_results__", products)

    if not products:
        reply = f"I couldn\'t find products for \'{search_query}\' on Amazon right now. Try a different search term!"
        await manager.send(ws, {"type": "chat_reply", "data": {"text": reply}, "done": True})
        return

    await manager.send(ws, {"type": "status", "message": f"Scoring {len(products)} products with AI..."})
    scored = await score_products(products, intent)
    await manager.send(ws, {"type": "scored_products", "data": scored})

    await manager.send(ws, {"type": "status", "message": "Picking the best options..."})
    rec = await build_recommendation(scored, intent)
    await manager.send(ws, {"type": "recommendation", "data": rec, "done": True})


async def handle_analyze(ws, payload):
    from ai.scorer import analyze_single_product
    page_data = payload.get("pageData", {})
    await manager.send(ws, {"type": "status", "message": "Analysing product..."})
    analysis = await analyze_single_product(page_data)
    await manager.send(ws, {"type": "analysis", "data": analysis, "done": True})


async def groq_chat(text: str, page_context: str = "") -> str:
    """Call Groq for a conversational reply."""
    try:
        msgs = [{"role": "user", "content": f"{page_context}\n\nUser: {text}".strip() if page_context else text}]
        resp = groq_client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[{"role": "system", "content": BILLY_SYSTEM}] + msgs,
            max_tokens=200,
            temperature=0.7,
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        print(f"Groq chat error: {e}")
        return "Hey! I\'m having a little trouble right now. Try asking me again!"


@app.get("/health")
async def health():
    return {"status": "ok", "service": "Billy AI", "version": "2.0.0"}


if __name__ == "__main__":
    uvicorn.run("main:app",
        host=os.getenv("HOST", "0.0.0.0"),
        port=int(os.getenv("PORT", 8000)),
        reload=True,
        ws_ping_interval=20,
        ws_ping_timeout=20,
    )
