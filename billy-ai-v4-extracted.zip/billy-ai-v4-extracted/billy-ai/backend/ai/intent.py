"""
ai/intent.py v2 — Smart intent detection
Never blindly searches. Understands context like a chatbot.
"""
import re

# These are conversational phrases Billy should NEVER search for
CHAT_ONLY_PATTERNS = [
    r"^(hey|hi|hello|yo|sup|what'?s up)\b",
    r"^(how are you|how'?s it going|good morning|good evening|good afternoon)",
    r"^(who are you|what are you|what can you do|help me|what'?s your name)",
    r"^(thanks|thank you|ok|okay|cool|great|awesome|nice|got it|perfect)",
    r"^(yes|no|maybe|sure|alright|fine|ok)",
    r"^(compare|analyse|analyze|review|tell me|what do you think|should i|is this)$",
]

# These MUST trigger product search
SEARCH_TRIGGERS = [
    r"\b(find|search|look for|show me|get me|i need|i want to buy|i want a|buy)\b.{3,}",
    r"\b(best|top|cheapest|good).{2,}(under|below|within|for|laptop|phone|mouse|fridge|tv|watch|speaker|headphone|keyboard|tablet|camera|ac|fan|cooler|washing)\b",
    r"\b(laptop|phone|mobile|fridge|refrigerator|tv|television|mouse|keyboard|headphone|earphone|speaker|tablet|camera|smartwatch|router|printer|monitor|ac|washing machine|cooler|fan)\b.{0,20}(under|below|within|budget|cheap|best|good|recommend)",
]

# Compare triggers — must NOT become search queries
COMPARE_TRIGGERS = [
    r"\bcompare (these|them|all|the|this|products|items|results|options)\b",
    r"\bwhich (is|one is|are) (best|better|cheapest|good|recommended)\b",
    r"\b(vs|versus)\b",
    r"\b(compare|comparison)\b.{0,10}$",
]

# Analyse current page
ANALYSE_TRIGGERS = [
    r"\b(analyse|analyze|analysis|review this|tell me about this|about this product|this product)\b",
    r"\b(should i buy|worth buying|worth it|good deal|is it good|is this good)\b",
    r"\b(delivery|when will|arrive|specs|specifications|features|details)\b",
    r"\b(fake reviews|review quality|seller|warranty|return policy)\b",
]

def detect_intent(text: str) -> dict:
    t = text.lower().strip()
    
    # 1. Pure chat — respond conversationally, never search
    for pattern in CHAT_ONLY_PATTERNS:
        if re.search(pattern, t):
            return {"intent": "chat", "query": t, "original": text,
                    "max_price": None, "category": None, "quality": "best"}
    
    # 2. Compare intent — compare already found products
    for pattern in COMPARE_TRIGGERS:
        if re.search(pattern, t):
            return {"intent": "compare", "query": t, "original": text,
                    "max_price": None, "category": None, "quality": "best"}
    
    # 3. Analyse current page
    for pattern in ANALYSE_TRIGGERS:
        if re.search(pattern, t):
            return {"intent": "analyze_page", "query": t, "original": text,
                    "max_price": None, "category": None, "quality": "best"}
    
    # 4. Explicit product search
    for pattern in SEARCH_TRIGGERS:
        if re.search(pattern, t):
            query = extract_product_query(t)
            return {"intent": "search", "query": query, "original": text,
                    "max_price": extract_price(t), "category": detect_category(t),
                    "quality": detect_quality(t)}
    
    # 5. Default — treat as chat, not search
    return {"intent": "chat", "query": t, "original": text,
            "max_price": None, "category": None, "quality": "best"}


def extract_product_query(text: str) -> str:
    clean = re.sub(r"^(hey|hi|ok|okay)\s+billy[\s,]*", "", text)
    clean = re.sub(r"^(find|search for|look for|show me|i need|i want to buy|get me|buy|i want a|i want an)\s+", "", clean)
    clean = re.sub(r"^(a|an|the|some)\s+", "", clean)
    clean = re.sub(r"\s*(under|below|less than|within)\s*(?:rs\.?|₹)?\s*\d[\d,]*", "", clean)
    clean = re.sub(r"\b(best|top|good|budget|cheap|premium|affordable|cheapest)\s+", "", clean)
    return clean.strip()


def extract_price(text: str) -> int | None:
    m = re.search(r"(under|below|within|less than)\s*(?:rs\.?|₹)?\s*(\d[\d,]*)", text)
    if m:
        return int(m.group(2).replace(",", ""))
    return None


def detect_category(text: str) -> str | None:
    cats = {
        "electronics":  r"\b(phone|mobile|laptop|tablet|tv|television|monitor|headphone|earphone|speaker|camera|smartwatch|router|earbuds)\b",
        "appliances":   r"\b(fridge|refrigerator|washing machine|ac|air conditioner|fan|cooler|microwave|mixer|geyser)\b",
        "computers":    r"\b(keyboard|mouse|hard disk|ssd|ram|processor|gpu|graphics card|pendrive|webcam|ups)\b",
    }
    for cat, pattern in cats.items():
        if re.search(pattern, text):
            return cat
    return None


def detect_quality(text: str) -> str:
    if re.search(r"\b(budget|cheap|affordable|low cost|under)\b", text): return "budget"
    if re.search(r"\b(premium|high end|best quality|top|luxury|professional)\b", text): return "premium"
    return "best"


# Keep async wrapper for compatibility
async def extract_intent(text: str) -> dict:
    return detect_intent(text)
