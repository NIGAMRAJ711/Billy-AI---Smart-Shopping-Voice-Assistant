"""
ai/scorer.py  — powered by Groq (free, fast)
Scores products across value, quality, delivery, review authenticity.
Uses llama3-70b running on Groq's free tier.
"""

import json
import os
import re
from groq import Groq

client = Groq(api_key=os.getenv("GROQ_API_KEY"))
MODEL  = os.getenv("GROQ_MODEL", "llama3-70b-8192")


async def score_products(products: list[dict], intent: dict) -> list[dict]:
    """
    Send scraped products to Groq/Llama3 for intelligent scoring.
    Scores each product 1-10 on value, quality, delivery, authenticity.
    Returns products sorted by overall score.
    """
    if not products:
        return []

    product_list = ""
    for i, p in enumerate(products, 1):
        product_list += (
            f"\nProduct {i}:\n"
            f"  Name: {str(p.get('name','?'))[:80]}\n"
            f"  Price: Rs.{p.get('price','?')}  MRP: Rs.{p.get('mrp','?')}  Discount: {p.get('discount','?')}%\n"
            f"  Rating: {p.get('rating','?')}/5  Reviews: {p.get('reviews','?')}\n"
            f"  Delivery: {p.get('delivery','?')}\n"
            f"  Prime: {p.get('prime', False)}  Badge: {p.get('badge','none')}\n"
        )

    prompt = f"""You are a sharp product analyst for Indian shoppers.

User wants: {intent.get('original')}
Category: {intent.get('category','general')}
Quality preference: {intent.get('quality','best')}
Max price: Rs.{intent.get('max_price','no limit')}

Products:
{product_list}

Score EACH product (1-10) on:
- value_score: price vs features vs Indian market average
- quality_score: rating credibility + review count
- delivery_score: speed (Prime/fast = high, slow = low)
- authenticity_score: review count realism (10k+ = authentic, under 50 = suspicious)
- overall_score: weighted (value 35%, quality 35%, delivery 20%, auth 10%)

Tag each as: best_overall, best_budget, best_premium, or skip

Return ONLY this JSON structure, nothing else, no markdown:
{{"products":[{{"index":1,"value_score":8.5,"quality_score":9.0,"delivery_score":9.0,"authenticity_score":8.0,"overall_score":8.7,"tag":"best_overall","one_line_reason":"Great value with verified reviews"}}],"summary":"2 sentence summary for shopper"}}"""

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1500,
            temperature=0.3,  # low temp = more consistent scoring
        )

        raw = response.choices[0].message.content.strip()
        # Strip accidental markdown fences
        raw = re.sub(r'^```json\s*|\s*```$', '', raw, flags=re.MULTILINE).strip()
        # Sometimes Llama adds text before the JSON — find the first {
        start = raw.find('{')
        if start > 0:
            raw = raw[start:]
        result = json.loads(raw)

        # Merge scores back into product dicts
        scored = []
        for score_data in result.get("products", []):
            idx = score_data["index"] - 1
            if 0 <= idx < len(products):
                p = products[idx].copy()
                p.update({
                    "value_score":        score_data.get("value_score"),
                    "quality_score":      score_data.get("quality_score"),
                    "delivery_score":     score_data.get("delivery_score"),
                    "authenticity_score": score_data.get("authenticity_score"),
                    "overall_score":      score_data.get("overall_score"),
                    "tag":                score_data.get("tag"),
                    "reason":             score_data.get("one_line_reason"),
                    "search_summary":     result.get("summary", ""),
                })
                scored.append(p)

        scored.sort(key=lambda x: x.get("overall_score") or 0, reverse=True)
        return scored

    except Exception as e:
        print(f"Scoring error: {e}")
        # Fallback: sort by rating
        products.sort(key=lambda x: float(x.get("rating") or 0), reverse=True)
        return products


async def analyze_single_product(page_data: dict) -> dict:
    """Deep analysis of one product page — verdict, pros, cons, fake review check."""

    specs_text = "\n".join(
        f"  {k}: {v}" for k, v in (page_data.get("specs") or {}).items()
    )[:600]

    reviews_text = "\n".join(
        f"  - {r}" for r in (page_data.get("reviews_text") or [])
    )[:400]

    prompt = f"""Analyse this product for an Indian shopper. Be direct and honest.

Product: {page_data.get('name','')}
Price: Rs.{page_data.get('price','')}
Rating: {page_data.get('rating','')}  Reviews: {page_data.get('review_count','')}
Delivery: {page_data.get('delivery','')} — {page_data.get('delivery_date','')}
Seller: {page_data.get('seller','')}
Bank offer: {page_data.get('bank_offer','')}
Availability: {page_data.get('availability','')}

Specs:
{specs_text or '  Not available'}

Sample reviews:
{reviews_text or '  Not available'}

Return ONLY this JSON, nothing else, no markdown:
{{"verdict":"buy","overall_score":8.2,"value_for_money":"excellent","fake_review_risk":"low","fake_review_reason":"High review count with consistent ratings","pros":["pro1","pro2","pro3"],"cons":["con1","con2"],"delivery_summary":"Arrives in 2-3 days","best_for":"Who this suits","billy_says":"2 sentence friendly recommendation"}}"""

    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=700,
            temperature=0.3,
        )
        raw = response.choices[0].message.content.strip()
        raw = re.sub(r'^```json\s*|\s*```$', '', raw, flags=re.MULTILINE).strip()
        start = raw.find('{')
        if start > 0:
            raw = raw[start:]
        return json.loads(raw)

    except Exception as e:
        print(f"Analysis error: {e}")
        return {
            "verdict": "consider",
            "overall_score": None,
            "billy_says": "I had trouble analysing this. Try asking me again!",
            "error": str(e)
        }
