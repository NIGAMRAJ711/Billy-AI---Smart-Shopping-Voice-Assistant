"""
ai/recommender.py — powered by Groq (free)
Builds final recommendation with best/budget/premium picks
and a voice script for Billy to speak.
"""

import os
from groq import Groq

client = Groq(api_key=os.getenv("GROQ_API_KEY"))
MODEL  = os.getenv("GROQ_MODEL", "llama3-70b-8192")


async def build_recommendation(scored_products: list[dict], intent: dict) -> dict:
    """
    From scored + ranked products, build the final recommendation output.
    Picks best_overall, best_budget, best_premium.
    Writes Billy's spoken voice script.
    """
    if not scored_products:
        return {"billy_says": "I couldn't find products to compare. Try a different search!"}

    # Find category winners from AI tags
    best_overall = next((p for p in scored_products if p.get("tag") == "best_overall"), scored_products[0])
    best_budget  = next((p for p in scored_products if p.get("tag") == "best_budget"),  None)
    best_premium = next((p for p in scored_products if p.get("tag") == "best_premium"), None)

    # Derive budget/premium from price if not tagged
    priced = [p for p in scored_products if p.get("price")]
    if not best_budget and priced:
        best_budget = sorted(priced, key=lambda x: float(x.get("price") or 99999))[0]
    if not best_premium and len(scored_products) > 1:
        # Second highest score = premium alternative
        best_premium = scored_products[1] if scored_products[1] != best_overall else None

    # Build voice script — short, spoken-word friendly, no markdown
    name   = (best_overall.get("name") or "")[:45]
    price  = best_overall.get("price", "?")
    score  = best_overall.get("overall_score", "?")
    reason = best_overall.get("reason", "great value for money")

    voice_script = (
        f"Alright, I compared {len(scored_products)} products for you! "
        f"My top pick is {name}, priced at Rs.{price} "
        f"with a score of {score} out of 10. "
        f"{reason}."
    )

    if best_budget and _asin(best_budget) != _asin(best_overall):
        bname  = (best_budget.get("name") or "")[:30]
        bprice = best_budget.get("price", "?")
        voice_script += (
            f" On a budget? Check out {bname} at Rs.{bprice} — solid value."
        )

    return {
        "best_overall": _clean(best_overall),
        "best_budget":  _clean(best_budget)  if best_budget  else None,
        "best_premium": _clean(best_premium) if best_premium else None,
        "all_products": [_clean(p) for p in scored_products],
        "billy_says":   voice_script,
        "summary":      scored_products[0].get("search_summary", ""),
        "total":        len(scored_products),
    }


def _asin(p):
    return p.get("asin") or p.get("url") or ""


def _clean(p: dict) -> dict:
    """Only the fields the frontend needs."""
    if not p:
        return {}
    return {
        "name":               p.get("name"),
        "price":              p.get("price"),
        "mrp":                p.get("mrp"),
        "discount":           p.get("discount"),
        "rating":             p.get("rating"),
        "reviews":            p.get("reviews"),
        "delivery":           p.get("delivery"),
        "prime":              p.get("prime"),
        "badge":              p.get("badge"),
        "image":              p.get("image"),
        "url":                p.get("url"),
        "overall_score":      p.get("overall_score"),
        "value_score":        p.get("value_score"),
        "quality_score":      p.get("quality_score"),
        "delivery_score":     p.get("delivery_score"),
        "authenticity_score": p.get("authenticity_score"),
        "tag":                p.get("tag"),
        "reason":             p.get("reason"),
    }
