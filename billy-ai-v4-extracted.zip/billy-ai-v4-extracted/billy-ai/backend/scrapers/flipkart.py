"""
scrapers/flipkart.py
Playwright-based Flipkart scraper.
Same streaming generator pattern as amazon.py.
"""

import asyncio
import os
import random
from typing import AsyncGenerator
from playwright.async_api import async_playwright

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
]

MAX_PRODUCTS = int(os.getenv("MAX_PRODUCTS", 8))
HEADLESS = os.getenv("HEADLESS", "true").lower() == "true"


async def scrape_flipkart_search(query: str) -> AsyncGenerator[dict, None]:
    """Search Flipkart and stream product cards."""
    url = f"https://www.flipkart.com/search?q={query.replace(' ', '+')}"

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=HEADLESS,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"]
        )
        context = await browser.new_context(
            user_agent=random.choice(USER_AGENTS),
            viewport={"width": 1280, "height": 800}
        )
        await context.route("**/*.{png,jpg,jpeg,gif,webp,woff,woff2}", lambda r: r.abort())
        page = await context.new_page()

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            # Wait for product grid
            await page.wait_for_selector("._1AtVbE, ._4ddWXP", timeout=15000)
            await asyncio.sleep(0.5)

            cards = await page.query_selector_all("._1AtVbE, ._4ddWXP")
            count = 0

            for card in cards:
                if count >= MAX_PRODUCTS:
                    break

                async def text(sel):
                    el = await card.query_selector(sel)
                    return (await el.inner_text()).strip() if el else None

                name    = await text("._4rR01T, .s1Q9rs, .IRpwTa")
                price   = await text("._30jeq3")
                rating  = await text("._3LWZlK")
                reviews = await text("._2_R_DZ span")
                url_el  = await card.query_selector("a._1fQZEK, a.s1Q9rs, a")
                prod_url = await url_el.get_attribute("href") if url_el else None
                if prod_url and not prod_url.startswith("http"):
                    prod_url = "https://www.flipkart.com" + prod_url

                if name:
                    count += 1
                    yield {
                        "name":    name,
                        "price":   price.replace("₹", "").replace(",", "").strip() if price else None,
                        "rating":  rating,
                        "reviews": reviews,
                        "url":     prod_url,
                        "prime":   False,
                        "source":  "flipkart",
                        "score":   None,
                    }
                    await asyncio.sleep(0.1)

        except Exception as e:
            print(f"Flipkart scraper error: {e}")
        finally:
            await browser.close()
