"""
scrapers/amazon.py
Playwright-based Amazon scraper.
Uses a real headless browser — handles JS-heavy pages, dynamic content,
lazy loading. Far more reliable than querySelector hacks.
Streams products as they're found via async generator.
"""

import asyncio
import os
import random
from typing import AsyncGenerator

from playwright.async_api import async_playwright, Page, BrowserContext

# Rotate user agents so Amazon doesn't block us
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
]

MAX_PRODUCTS = int(os.getenv("MAX_PRODUCTS", 10))
HEADLESS     = os.getenv("HEADLESS", "true").lower() == "true"


async def scrape_search_results(query: str) -> AsyncGenerator[dict, None]:
    """
    Search Amazon for `query`, scrape top products.
    Yields each product as soon as it's extracted — streaming!
    """
    url = f"https://www.amazon.in/s?k={query.replace(' ', '+')}"

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=HEADLESS,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"]
        )

        context = await browser.new_context(
            user_agent=random.choice(USER_AGENTS),
            viewport={"width": 1280, "height": 800},
            # Pretend to be a real browser
            extra_http_headers={
                "Accept-Language": "en-IN,en;q=0.9",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            }
        )

        # Block images/fonts to load faster
        await context.route("**/*.{png,jpg,jpeg,gif,webp,svg,woff,woff2,ttf}", 
                           lambda route: route.abort())

        page = await context.new_page()

        try:
            print(f"🔍 Scraping: {url}")
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)

            # Wait for product results to appear
            await page.wait_for_selector(
                '[data-component-type="s-search-result"]',
                timeout=15000
            )

            # Scroll to load lazy content
            await page.evaluate("window.scrollTo(0, document.body.scrollHeight / 2)")
            await asyncio.sleep(0.8)

            # Extract all product cards
            cards = await page.query_selector_all('[data-component-type="s-search-result"]')
            print(f"📦 Found {len(cards)} products")

            count = 0
            for card in cards:
                if count >= MAX_PRODUCTS:
                    break

                product = await extract_product_card(card, page)
                if product and product.get("name"):
                    count += 1
                    yield product
                    # Small delay between extractions — feels more natural
                    await asyncio.sleep(0.1)

        except Exception as e:
            print(f"❌ Scraper error: {e}")
        finally:
            await browser.close()


async def extract_product_card(card, page: Page) -> dict:
    """Extract all data from a single product card."""
    try:
        # Helper: safely get text from selector within card
        async def text(sel):
            el = await card.query_selector(sel)
            return (await el.inner_text()).strip() if el else None

        async def attr(sel, attribute):
            el = await card.query_selector(sel)
            return await el.get_attribute(attribute) if el else None

        name     = await text("h2 a span")
        price    = await text(".a-price-whole")
        mrp_el   = await card.query_selector(".a-text-price .a-offscreen")
        mrp      = (await mrp_el.inner_text()).replace("₹","").replace(",","").strip() if mrp_el else None
        rating   = await text(".a-icon-alt")
        reviews  = await text(".a-size-base.s-underline-text")
        delivery = await text(".a-color-base.a-text-bold")
        badge    = await text(".a-badge-text")  # "Amazon's Choice", "Best Seller" etc
        prime    = await card.query_selector(".s-prime") is not None
        url_el   = await card.query_selector("h2 a")
        url      = await url_el.get_attribute("href") if url_el else None
        asin     = await attr("[data-asin]", "data-asin")
        img      = await attr(".s-image", "src")

        # Clean up data
        if price: price = price.replace(",", "").strip()
        if rating: rating = rating.split(" ")[0]  # "4.3 out of 5 stars" → "4.3"
        if url and not url.startswith("http"): url = "https://www.amazon.in" + url

        # Calculate discount
        discount = None
        if price and mrp:
            try:
                p, m = float(price), float(mrp)
                if m > p: discount = round((m - p) / m * 100)
            except: pass

        return {
            "name":     name,
            "price":    price,
            "mrp":      mrp,
            "discount": discount,
            "rating":   float(rating) if rating else None,
            "reviews":  reviews,
            "delivery": delivery,
            "badge":    badge,
            "prime":    prime,
            "url":      url,
            "asin":     asin,
            "image":    img,
            "source":   "amazon",
            "score":    None,   # filled in by AI scorer
        }
    except Exception as e:
        print(f"⚠️  Card extraction error: {e}")
        return {}


async def scrape_product_page(url: str) -> dict:
    """
    Scrape a full product page for deep analysis.
    Gets specs, all reviews excerpt, seller info, delivery dates.
    """
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=HEADLESS,
            args=["--no-sandbox"])
        context = await browser.new_context(
            user_agent=random.choice(USER_AGENTS),
            viewport={"width": 1280, "height": 900}
        )
        await context.route("**/*.{png,jpg,jpeg,gif,webp,woff,woff2}", 
                           lambda route: route.abort())
        page = await context.new_page()

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_selector("#productTitle", timeout=10000)

            async def text(sel):
                el = await page.query_selector(sel)
                return (await el.inner_text()).strip() if el else None

            # Extract specs table
            specs = {}
            rows = await page.query_selector_all(
                "#productOverview_feature_div tr, "
                "#productDetails_techSpec_section_1 tr"
            )
            for row in rows:
                cells = await row.query_selector_all("td, th")
                if len(cells) >= 2:
                    k = (await cells[0].inner_text()).strip()[:40]
                    v = (await cells[1].inner_text()).strip()[:80]
                    if k and v: specs[k] = v

            # Top reviews
            reviews_text = []
            review_els = await page.query_selector_all(
                '[data-hook="review-body"] span'
            )
            for el in review_els[:5]:
                t = (await el.inner_text()).strip()
                if len(t) > 20: reviews_text.append(t[:200])

            return {
                "name":          await text("#productTitle"),
                "price":         await text(".a-price-whole"),
                "rating":        await text("#acrPopover [title]"),
                "review_count":  await text("#acrCustomerReviewText"),
                "delivery":      await text("#deliveryBlockMessage, #mir-layout-DELIVERY_BLOCK"),
                "delivery_date": await text("#deliveryMessageMirId"),
                "seller":        await text("#merchant-info, #sellerProfileTriggerId"),
                "availability":  await text("#availability span"),
                "bank_offer":    await text("#sopp_feature_div"),
                "specs":         specs,
                "reviews_text":  reviews_text,
                "url":           url,
            }
        finally:
            await browser.close()
