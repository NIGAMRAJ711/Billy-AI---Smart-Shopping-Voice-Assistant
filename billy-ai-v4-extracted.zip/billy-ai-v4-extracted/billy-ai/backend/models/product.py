"""
models/product.py
Pydantic data models for products throughout the pipeline.
"""

from pydantic import BaseModel
from typing import Optional


class Product(BaseModel):
    name:               Optional[str] = None
    price:              Optional[str] = None
    mrp:                Optional[str] = None
    discount:           Optional[int] = None
    rating:             Optional[float] = None
    reviews:            Optional[str] = None
    delivery:           Optional[str] = None
    prime:              bool = False
    badge:              Optional[str] = None
    image:              Optional[str] = None
    url:                Optional[str] = None
    asin:               Optional[str] = None
    source:             str = "amazon"

    # Filled by AI scorer
    overall_score:      Optional[float] = None
    value_score:        Optional[float] = None
    quality_score:      Optional[float] = None
    delivery_score:     Optional[float] = None
    authenticity_score: Optional[float] = None
    tag:                Optional[str] = None
    reason:             Optional[str] = None


class SearchIntent(BaseModel):
    original:  str
    intent:    str
    query:     str
    max_price: Optional[int] = None
    category:  Optional[str] = None
    quality:   str = "best"


class Recommendation(BaseModel):
    best_overall:  Optional[dict] = None
    best_budget:   Optional[dict] = None
    best_premium:  Optional[dict] = None
    all_products:  list[dict] = []
    billy_says:    str = ""
    summary:       str = ""
    total:         int = 0
