# 🛍️ Billy AI — Production Shopping Assistant

> Voice-activated AI that searches, scrapes, scores and compares products in real-time.

---

## 📁 Project Structure

```
billy-ai/
├── backend/              ← Python FastAPI server (the brain)
│   ├── main.py           ← Server entry point
│   ├── routers/          ← API routes
│   ├── scrapers/         ← Playwright scrapers
│   ├── ai/               ← Claude scoring engine
│   ├── cache/            ← Redis caching layer
│   └── models/           ← Data models
├── extension/            ← Chrome Extension (the face)
│   ├── src/              ← React UI
│   ├── public/           ← Icons, manifest
│   └── package.json
├── shared/               ← Shared types/constants
├── setup.sh              ← One-command setup
└── README.md
```

---

## 🚀 Setup From Zero (Step by Step)

### Step 1 — Install Python
Download from https://python.org (3.11 or higher)
During install: ✅ check "Add Python to PATH"

### Step 2 — Install Node.js
Download from https://nodejs.org (LTS version)

### Step 3 — Install Redis (Windows)
Download from https://github.com/microsoftarchive/redis/releases
Install Redis-x64-3.0.504.msi, keep default settings

### Step 4 — Run the setup script
```bash
# On Windows: double-click setup.bat
# On Mac/Linux:
chmod +x setup.sh && ./setup.sh
```

### Step 5 — Add your API key
Edit `backend/.env`:
```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```
Get a key at: https://console.anthropic.com

### Step 6 — Start the backend
```bash
cd backend
python main.py
```
You should see: `Billy backend running on http://localhost:8000`

### Step 7 — Load the Chrome Extension
1. Open Chrome → go to `chrome://extensions`
2. Enable "Developer mode" (top right)
3. Click "Load unpacked"
4. Select the `extension/` folder

### Step 8 — Say "Hey Billy"!

---

## 🎯 How It Works

1. You say "Hey Billy, find best gaming mouse"
2. Extension captures voice → sends to backend via WebSocket
3. Backend detects intent + extracts "gaming mouse"
4. Playwright opens Amazon headlessly, scrapes top 10 products
5. Claude scores each product 1–10 on value/quality/delivery
6. Results stream back to extension in real-time
7. Billy speaks the winner + shows comparison table

---

## ⚡ Performance Targets
- Wake word response: < 200ms
- First result shown: < 2 seconds  
- Full comparison: < 5 seconds
- Cached query: < 300ms
