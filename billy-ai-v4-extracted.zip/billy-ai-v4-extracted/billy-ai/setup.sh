#!/bin/bash
echo "🛍️  Setting up Billy AI..."

# Backend
echo "📦 Installing Python dependencies..."
cd backend
python -m venv venv
source venv/bin/activate 2>/dev/null || source venv/Scripts/activate 2>/dev/null
pip install -r requirements.txt
playwright install chromium
cp .env.example .env
echo "✅ Backend ready"

# Extension
echo "📦 Installing extension dependencies..."
cd ../extension
npm install
npm run build
echo "✅ Extension built"

echo ""
echo "✅ Setup complete!"
echo "👉 Next: Add your API key to backend/.env"
echo "👉 Then run: cd backend && python main.py"
